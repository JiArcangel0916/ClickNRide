//  // User database
const users = [
    { username: "admin", password: "admin123", role: "admin" },
    { username: "user123", password: "password123", role: "user" }
];

function login() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!username || !password) {
        alert('Please enter your credentials.');
        return;
    }

    const user = users.find(u => u.username === username && u.password === password);
    
    if (user) {
        sessionStorage.setItem('currentUser', JSON.stringify(user));
        
        if (user.role === "admin") {
            alert(`Welcome Admin, ${username}!`);
            window.location.href = "admin.html";
        } else {
            alert(`Welcome, ${username}!`);
            document.getElementById('auth-screen').style.display = 'none';
        }
    } else {
        alert('Invalid username or password.');
    }
}

function toggleSignup() {
    document.querySelector('.auth-box').classList.toggle('show-signup');
}

function signup() {
    const newUser = document.getElementById('new-username').value.trim();
    const newPass = document.getElementById('new-password').value.trim();

    if (newUser && newPass) {
        if (users.some(u => u.username === newUser)) {
            alert('Username already exists!');
            return;
        }
        users.push({ username: newUser, password: newPass, role: "user" });
        alert(`Account created for ${newUser}! You can now log in.`);
        toggleSignup();
    } else {
        alert('Please complete the sign-up form.');
    }
}