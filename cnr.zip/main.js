
//  // User database
const users = [
    { username: "admin", password: "admin123", role: "admin" },
    { username: "user123", password: "password123", role: "user" }
];

function login() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!username || !password) {
        alert('Please enter your credentials.');
        return;
    }

    const user = users.find(u => u.username === username && u.password === password);
    
    if (user) {
        sessionStorage.setItem('currentUser', JSON.stringify(user));
        
        if (user.role === "admin") {
            alert(`Welcome Admin, ${username}!`);
            window.location.href = "admin.html";
        } else {
            alert(`Welcome, ${username}!`);
            document.getElementById('auth-screen').style.display = 'none';
        }
    } else {
        alert('Invalid username or password.');
    }
}

function toggleSignup() {
    document.querySelector('.auth-box').classList.toggle('show-signup');
}

function signup() {
    const newUser = document.getElementById('new-username').value.trim();
    const newPass = document.getElementById('new-password').value.trim();

    if (newUser && newPass) {
        if (users.some(u => u.username === newUser)) {
            alert('Username already exists!');
            return;
        }
        users.push({ username: newUser, password: newPass, role: "user" });
        alert(`Account created for ${newUser}! You can now log in.`);
        toggleSignup();
    } else {
        alert('Please complete the sign-up form.');
    }
}
// Sample data
let tickets = [];
let currentUser = {
    username: "user123",
    email: "user@example.com",
    mobile: "+1 234 567 8900",
    password: "password123"
};

// Fare matrix data
const fareMatrix = {
    "main-terminal": {
        "main-terminal": 0,
        "downtown": 2.50,
        "university": 3.00,
        "shopping-mall": 3.50,
        "suburb-east": 4.00
    },
    "downtown": {
        "main-terminal": 2.50,
        "downtown": 0,
        "university": 1.50,
        "shopping-mall": 2.00,
        "suburb-east": 2.50
    },
    "university": {
        "main-terminal": 3.00,
        "downtown": 1.50,
        "university": 0,
        "shopping-mall": 1.00,
        "suburb-east": 1.50
    },
    "shopping-mall": {
        "main-terminal": 3.50,
        "downtown": 2.00,
        "university": 1.00,
        "shopping-mall": 0,
        "suburb-east": 1.00
    },
    "suburb-east": {
        "main-terminal": 4.00,
        "downtown": 2.50,
        "university": 1.50,
        "shopping-mall": 1.00,
        "suburb-east": 0
    }
};

const discounts = {
    "regular": 0,
    "student": 0.20,
    "senior": 0.25,
    "pwd": 0.30
};

// Reserved seats for PWD and seniors (simplified)
const reservedSeats = [1, 2, 15, 16]; // These seats are reserved for special categories

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    loadTickets();
});

// Navigation functions
function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
   
    // Show the selected section
    document.getElementById(sectionId).classList.add('active');
}

// Buy Ticket functions
function showFareMatrix() {
    const boarding = document.getElementById('boarding-location').value;
    const dropoff = document.getElementById('drop-off-location').value;
   
    if (!boarding || !dropoff) {
        alert('Please select both boarding and drop-off locations');
        return;
    }
   
    document.getElementById('fare-matrix').style.display = 'block';
}

function proceedToSummary() {
    const boarding = document.getElementById('boarding-location').value;
    const dropoff = document.getElementById('drop-off-location').value;
    const passengers = document.getElementById('passengers').value;
    const category = document.querySelector('input[name="category"]:checked').value;
   
    if (!boarding || !dropoff) {
        alert('Please select both boarding and drop-off locations');
        return;
    }
   
    if (boarding === dropoff) {
        alert('Boarding and drop-off locations cannot be the same');
        return;
    }
   
    if (passengers < 1 || passengers > 10) {
        alert('Number of passengers must be between 1 and 10');
        return;
    }
   
    // Calculate fare
    const baseFare = fareMatrix[boarding][dropoff];
    const discountRate = discounts[category];
    const discountAmount = baseFare * discountRate;
    const totalFare = (baseFare - discountAmount) * passengers;
   
    // Display summary
    document.getElementById('summary-boarding').textContent = document.getElementById('boarding-location').options[document.getElementById('boarding-location').selectedIndex].text;
    document.getElementById('summary-dropoff').textContent = document.getElementById('drop-off-location').options[document.getElementById('drop-off-location').selectedIndex].text;
    document.getElementById('summary-passengers').textContent = passengers;
    document.getElementById('summary-category').textContent = document.querySelector(`label[for="${category}"]`).textContent.trim();
    document.getElementById('summary-fare').textContent = `$${baseFare.toFixed(2)}`;
    document.getElementById('summary-discount').textContent = `${(discountRate * 100)}% ($${discountAmount.toFixed(2)})`;
    document.getElementById('summary-total').textContent = `$${totalFare.toFixed(2)}`;
   
    document.getElementById('ticket-summary').style.display = 'block';
   
    // Generate seat selection
    generateSeatSelection(passengers, category);
}

function generateSeatSelection(passengers, category) {
    const seatContainer = document.getElementById('seat-container');
    seatContainer.innerHTML = '';
   
    for (let i = 1; i <= 20; i++) { // Assuming 20 seats on the bus
        const seat = document.createElement('div');
        seat.className = 'seat-option';
        seat.textContent = i;
        seat.dataset.seatNumber = i;
       
        // Check if seat is reserved for special categories
        if (reservedSeats.includes(i) && (category === 'regular' || category === 'student')) {
            seat.classList.add('reserved');
            seat.title = 'Reserved for PWD/Senior Citizens';
        } else {
            seat.addEventListener('click', function() {
                toggleSeatSelection(this);
            });
        }
       
        seatContainer.appendChild(seat);
    }
}

function toggleSeatSelection(seatElement) {
    const selectedSeats = document.querySelectorAll('.seat-option.selected');
   
    // If seat is already selected, deselect it
    if (seatElement.classList.contains('selected')) {
        seatElement.classList.remove('selected');
        return;
    }
   
    // Check if we've reached the passenger limit
    const passengers = parseInt(document.getElementById('passengers').value);
    if (selectedSeats.length >= passengers) {
        alert(`You can only select ${passengers} seat(s) for ${passengers} passenger(s)`);
        return;
    }
   
    seatElement.classList.add('selected');
}

function selectPayment(method) {
    document.querySelectorAll('.payment-option').forEach(option => {
        option.classList.remove('selected');
    });
   
    document.querySelector(`.payment-option[onclick="selectPayment('${method}')"]`).classList.add('selected');
    document.querySelector(`input[value="${method}"]`).checked = true;
}

function processPayment() {
    const selectedSeats = document.querySelectorAll('.seat-option.selected');
    const passengers = parseInt(document.getElementById('passengers').value);
   
    if (selectedSeats.length !== passengers) {
        alert(`Please select exactly ${passengers} seat(s) for your ticket`);
        return;
    }
   
    // Simulate payment processing
    setTimeout(() => {
        document.getElementById('ticket-summary').style.display = 'none';
        document.getElementById('payment-success').style.display = 'block';
       
        // Generate ticket
        generateTicket();
    }, 1500);
}

function generateTicket() {
    const boarding = document.getElementById('boarding-location').value;
    const dropoff = document.getElementById('drop-off-location').value;
    const passengers = document.getElementById('passengers').value;
    const category = document.querySelector('input[name="category"]:checked').value;
    const baseFare = fareMatrix[boarding][dropoff];
    const discountRate = discounts[category];
    const discountAmount = baseFare * discountRate;
    const totalFare = (baseFare - discountAmount) * passengers;
   
    const selectedSeats = Array.from(document.querySelectorAll('.seat-option.selected')).map(seat => seat.dataset.seatNumber);
   
    // Generate ticket ID (timestamp + random number for uniqueness)
    const ticketId = Date.now() + '-' + Math.floor(Math.random() * 1000);
   
    // Create ticket object
    const ticket = {
        id: ticketId,
        boarding: boarding,
        boardingName: document.getElementById('boarding-location').options[document.getElementById('boarding-location').selectedIndex].text,
        dropoff: dropoff,
        dropoffName: document.getElementById('drop-off-location').options[document.getElementById('drop-off-location').selectedIndex].text,
        passengers: passengers,
        category: category,
        categoryName: document.querySelector(`label[for="${category}"]`).textContent.trim(),
        fare: baseFare,
        discount: discountRate,
        total: totalFare,
        seats: selectedSeats,
        purchaseDate: new Date(),
        status: 'active',
        qrCode: `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${ticketId}`
    };
   
    // Add to tickets array
    tickets.push(ticket);
   
    // Display QR code
    document.getElementById('ticket-qr').src = ticket.qrCode;
    document.getElementById('ticket-id').textContent = `Ticket ID: ${ticketId}`;
   
    // Save to "database"
    saveTickets();
   
    // Update My Tickets view
    loadTickets();
}

// My Tickets functions
function loadTickets() {
    const activeTicketsList = document.getElementById('active-tickets-list');
    const closedTicketsList = document.getElementById('closed-tickets-list');
   
    activeTicketsList.innerHTML = '';
    closedTicketsList.innerHTML = '';
   
    // Load from localStorage if available
    const savedTickets = localStorage.getItem('clicknride_tickets');
    if (savedTickets) {
        tickets = JSON.parse(savedTickets);
    }
   
    if (tickets.length === 0) {
        activeTicketsList.innerHTML = '<p>No active tickets found</p>';
        closedTicketsList.innerHTML = '<p>No closed tickets found</p>';
        return;
    }
   
    tickets.forEach(ticket => {
        const ticketElement = document.createElement('div');
        ticketElement.className = `ticket-card ${ticket.status === 'used' ? 'used' : ''}`;
       
        let statusBadge = '';
        if (ticket.status === 'active') {
            statusBadge = '<span class="ticket-status status-active">Active</span>';
        } else {
            statusBadge = '<span class="ticket-status status-used">Used</span>';
        }
       
        ticketElement.innerHTML = `
            ${statusBadge}
            <p><strong>From:</strong> ${ticket.boardingName}</p>
            <p><strong>To:</strong> ${ticket.dropoffName}</p>
            <p><strong>Passengers:</strong> ${ticket.passengers} (${ticket.categoryName})</p>
            <p><strong>Seats:</strong> ${ticket.seats.join(', ')}</p>
            <p><strong>Total:</strong> $${ticket.total.toFixed(2)}</p>
            <p><strong>Purchase Date:</strong> ${ticket.purchaseDate.toLocaleString()}</p>
            <p><strong>Ticket ID:</strong> ${ticket.id}</p>
            ${ticket.status === 'active' ? `<div class="qr-code"><img src="${ticket.qrCode}" alt="QR Code"></div>` : ''}
        `;
       
        if (ticket.status === 'active') {
            activeTicketsList.appendChild(ticketElement);
        } else {
            closedTicketsList.appendChild(ticketElement);
        }
    });
}

function saveTickets() {
    localStorage.setItem('clicknride_tickets', JSON.stringify(tickets));
}

// Ticket Scan functions
function simulateScan() {
    if (tickets.length === 0) {
        alert('No tickets available to scan. Please purchase a ticket first.');
        return;
    }
   
    // Find an active ticket
    const activeTicket = tickets.find(ticket => ticket.status === 'active');
   
    if (!activeTicket) {
        alert('No active tickets found to scan');
        return;
    }
   
    // Simulate scanning
    const scannerLight = document.getElementById('scanner-light');
    const scannerResult = document.getElementById('scanner-result');
   
    scannerLight.classList.add('valid');
    scannerResult.textContent = 'Valid Ticket';
    scannerResult.className = 'scanner-result valid-result';
   
    // Mark ticket as used
    activeTicket.status = 'used';
    activeTicket.usedDate = new Date();
    saveTickets();
    loadTickets();
   
    // Reset after 3 seconds
    setTimeout(() => {
        scannerLight.classList.remove('valid');
        scannerResult.textContent = '';
    }, 3000);
}

function validateManualTicket() {
    const ticketNumber = document.getElementById('ticket-number').value.trim();
    const scannerResult = document.getElementById('scanner-result');
   
    if (!ticketNumber) {
        alert('Please enter a ticket ID');
        return;
    }
   
    // Find the ticket
    const ticket = tickets.find(t => t.id === ticketNumber);
   
    if (!ticket) {
        scannerResult.textContent = 'Invalid Ticket - Not Found';
        scannerResult.className = 'scanner-result invalid-result';
        return;
    }
   
    if (ticket.status === 'used') {
        scannerResult.textContent = 'Invalid Ticket - Already Used';
        scannerResult.className = 'scanner-result invalid-result';
    } else {
        scannerResult.textContent = 'Valid Ticket';
        scannerResult.className = 'scanner-result valid-result';
       
        // Mark ticket as used
        ticket.status = 'used';
        ticket.usedDate = new Date();
        saveTickets();
        loadTickets();
    }
}

// Profile functions
function changePassword() {
// First, get the current user from session storage
const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));

const current = document.getElementById('current-password').value;
const newPass = document.getElementById('new-password').value;
const confirm = document.getElementById('confirm-password').value;
const message = document.getElementById('password-message');

if (current !== currentUser.password) {
message.textContent = 'Current password is incorrect';
message.style.color = 'red';
return;
}

if (newPass.length < 6) {
message.textContent = 'New password must be at least 6 characters';
message.style.color = 'red';
return;
}

if (newPass !== confirm) {
message.textContent = 'New passwords do not match';
message.style.color = 'red';
return;
}

// Update password in the user object
currentUser.password = newPass;

// Update the user in session storage
sessionStorage.setItem('currentUser', JSON.stringify(currentUser));

// Update the user in the users array (if you want to persist it)
// This part is optional but helps if you're storing users in memory
const users = JSON.parse(sessionStorage.getItem('users')) || [];
const userIndex = users.findIndex(u => u.username === currentUser.username);
if (userIndex !== -1) {
users[userIndex].password = newPass;
sessionStorage.setItem('users', JSON.stringify(users));
}

message.textContent = 'Password changed successfully';
message.style.color = 'green';

// Clear fields
document.getElementById('current-password').value = '';
document.getElementById('new-password').value = '';
document.getElementById('confirm-password').value = '';
}

function logout() {
    // Clear session data
    sessionStorage.removeItem('currentUser');

    // Optional: Show a quick logout message before redirecting
    alert('You have been logged out.');

    // Redirect to login page
    window.location.href = 'login.html';
}


// Help functions
function toggleHelp() {
    const helpPopup = document.getElementById('help-popup');
    helpPopup.style.display = helpPopup.style.display === 'block' ? 'none' : 'block';
}